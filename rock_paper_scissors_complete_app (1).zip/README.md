# Rock Paper Scissors — Complete App

## Features
- Player vs Computer gameplay
- Random computer move
- Win / lose / draw detection
- Live score
- Reset button
- Responsive mobile-friendly UI
- No backend or installation required

## How to run
1. Extract the ZIP file.
2. Open the folder.
3. Double-click `index.html`.
4. Choose Rock, Paper, or Scissors.

## Technologies
- HTML5
- CSS3
- JavaScript

## Game rules
- Rock beats Scissors
- Scissors beats Paper
- Paper beats Rock
- Same choice = Draw
