const choices = {
  rock: "✊",
  paper: "✋",
  scissors: "✌️"
};

let playerScore = 0;
let computerScore = 0;

const playerScoreEl = document.getElementById("playerScore");
const computerScoreEl = document.getElementById("computerScore");
const playerChoiceEl = document.getElementById("playerChoice");
const computerChoiceEl = document.getElementById("computerChoice");
const resultEl = document.getElementById("result");

function computerMove() {
  const moves = Object.keys(choices);
  return moves[Math.floor(Math.random() * moves.length)];
}

function play(player) {
  const computer = computerMove();

  playerChoiceEl.textContent = choices[player];
  computerChoiceEl.textContent = choices[computer];

  if (player === computer) {
    resultEl.textContent = "It's a draw! 🤝";
  } else if (
    (player === "rock" && computer === "scissors") ||
    (player === "paper" && computer === "rock") ||
    (player === "scissors" && computer === "paper")
  ) {
    playerScore++;
    resultEl.textContent = "You win! 🎉";
  } else {
    computerScore++;
    resultEl.textContent = "Computer wins! 🤖";
  }

  playerScoreEl.textContent = playerScore;
  computerScoreEl.textContent = computerScore;
}

function resetGame() {
  playerScore = 0;
  computerScore = 0;
  playerScoreEl.textContent = "0";
  computerScoreEl.textContent = "0";
  playerChoiceEl.textContent = "❔";
  computerChoiceEl.textContent = "❔";
  resultEl.textContent = "Make your move!";
}

document.querySelectorAll(".move").forEach(button => {
  button.addEventListener("click", () => play(button.dataset.move));
});

document.getElementById("reset").addEventListener("click", resetGame);
